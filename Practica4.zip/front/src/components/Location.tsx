import { gql, useQuery } from '@apollo/client';
import { FC } from 'react';
import styles from '@/styles/location.module.css';
import Link from 'next/link';

const Location: FC<{ id: string }> = ({ id }) => {
  const query = gql`
  query Location($id: ID!) {
    location(id: $id) {
      name
      dimension
      residents {
        id
        name
    }
  } 
} 
  `;

  const { loading, error, data } = useQuery<{ 
    location: { name: string; dimension: string; residents: []} 
  }>(query, {
    variables: {
      id
    }
  });

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error! {error.message}</div>;

  return (

    <div className={styles.container}>
       <h2>Ubicacion</h2>
       {"\n"}
      <h1 className={styles.title}>{data!.location.name}</h1>
      <h2>Dimension</h2>
      {"\n"}
      <p>{data!.location.dimension}</p>
      <h2>Residentes</h2>
      {"\n"}
      <p>
        {data!.location.residents.map((residents) => (
          <div key={residents.name}>
            <Link href={`/character/${residents.id}`} passHref>
              {residents.name}
            </Link>
          </div>
        ))}
      </p>
    </div>
  )
}

export default Location;
